
    KindEditor.ready(function(K) {
        K.create('#id_content',{
            with:500,
            height:200
        });
    });
