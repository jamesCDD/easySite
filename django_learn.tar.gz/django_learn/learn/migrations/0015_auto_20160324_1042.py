# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('learn', '0014_auto_20160324_1041'),
    ]

    operations = [
        migrations.AlterField(
            model_name='titlebar',
            name='orderid',
            field=models.CharField(default=b'', max_length=30),
        ),
    ]
