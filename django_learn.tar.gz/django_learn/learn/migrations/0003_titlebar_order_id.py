# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('learn', '0002_titlebar_name_url'),
    ]

    operations = [
        migrations.AddField(
            model_name='titlebar',
            name='order_id',
            field=models.IntegerField(default=b'', max_length=10, verbose_name=b'\xe5\xba\x8f\xe5\x8f\xb7'),
        ),
    ]
