# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('learn', '0006_auto_20160324_0912'),
    ]

    operations = [
        migrations.AlterField(
            model_name='titlebar',
            name='order_id',
            field=models.IntegerField(default=0),
        ),
    ]
