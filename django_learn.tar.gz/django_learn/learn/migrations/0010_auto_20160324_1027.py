# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('learn', '0009_auto_20160324_1025'),
    ]

    operations = [
        migrations.AlterField(
            model_name='titlebar',
            name='order_id',
            field=models.IntegerField(max_length=30, verbose_name=b'\xe5\xba\x8f\xe5\x8f\xb7'),
        ),
    ]
