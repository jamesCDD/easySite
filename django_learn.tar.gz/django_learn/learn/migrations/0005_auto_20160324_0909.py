# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('learn', '0004_auto_20160324_0908'),
    ]

    operations = [
        migrations.AlterField(
            model_name='titlebar',
            name='order_id',
            field=models.IntegerField(verbose_name=b'\xe5\xba\x8f\xe5\x8f\xb7'),
        ),
    ]
