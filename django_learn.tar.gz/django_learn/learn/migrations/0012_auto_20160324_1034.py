# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('learn', '0011_auto_20160324_1028'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='titlebar',
            name='order_id',
        ),
        migrations.AddField(
            model_name='titlebar',
            name='orderid',
            field=models.IntegerField(default=0, max_length=30),
        ),
    ]
