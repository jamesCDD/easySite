# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('learn', '0003_titlebar_order_id'),
    ]

    operations = [
        migrations.AlterField(
            model_name='titlebar',
            name='order_id',
            field=models.IntegerField(default=b'', verbose_name=b'\xe5\xba\x8f\xe5\x8f\xb7'),
        ),
    ]
