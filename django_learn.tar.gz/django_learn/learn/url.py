# coding:utf8
from django.conf.urls import url
from learn.views import *

urlpatterns = [
    url(r'^$', index, name='index'),
    # url(r'^archive/$', archive, name='archive'),
    url(r'^message/$', message, name='article'),
    url(r'^home/$', home, name='home'),
    url(r'^pro_introduction/$', pro_introduction, name='pro_introduction'),
    url(r'^pro_introduction/(?P<req_id>\d+)$', pro_introduction, name='single_pro'),
    url(r'^contact/$', contact, name='contact'),
    ]