# coding:utf8
from django.conf.urls import url
from learn.views import *

urlpatterns = [
    url(r'^$', index, name='index'),
    # url(r'^archive/$', archive, name='archive'),
    # 主页
    url(r'^home/$', home, name='home'),
    # 消息动态
    url(r'^message/$', message, name='article'),
    # 产品介绍
    url(r'^pro_introduction/$', pro_introduction, name='pro_introduction'),
    url(r'^pro_introduction/(?P<req_id>\d+)$', pro_introduction, name='single_pro'),
    # 联系我们
    url(r'^contact/$', contact, name='contact'),
    # 人才招聘
    url(r'^hr/$', hr, name='hr'),
    # 文件上传
    # url(r'^uploads/$', uploads, name='uploads')
    ]