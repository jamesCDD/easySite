# coding:utf8
from django.shortcuts import render, redirect, HttpResponse
from models import *
import datetime
from django.core.paginator import Paginator, InvalidPage, EmptyPage, PageNotAnInteger

now = datetime.datetime.now()
other_style_time = now.strftime("%Y-%m-%d %H:%M:%S")


def index(request):

    try:
        title_bar = TitleBar.objects.all()
        return render(request, "index.html", locals())
    except Exception as e:
        print e


def message(request):
    global other_style_time
    title_bar = TitleBar.objects.all()
    other_style_time = other_style_time
    return render(request, "message.html", locals())


def home(request):
    try:
        title_bar = TitleBar.objects.all()
        return render(request, "index.html", locals())
    except Exception as e:
        print e


def pro_introduction(request, req_id=None):
    try:
        if req_id == None:
            title_bar = TitleBar.objects.all()
            article_all = Article.objects.all()
            article_all = getPage(request, article_all)
            return render(request, "pro_introduction.html", locals())
        else:
            title_bar = TitleBar.objects.all()
            single_pro = Article.objects.get(id=int(req_id))
            return render(request, "single_pro.html", locals())
    except Exception as e:
        print e


# 分页代码
def getPage(request, article_list):
    paginator = Paginator(article_list, 4)
    try:
        page = int(request.GET.get('page', 1))
        article_list = paginator.page(page)
    except (EmptyPage, InvalidPage, PageNotAnInteger):
        article_list = paginator.page(1)
    return article_list


# 联系我们
def contact(request):
    title_bar = TitleBar.objects.all()
    return render(request, "t.html", locals())


# 人才招聘
def hr(request):
    title_bar = TitleBar.objects.all()
    return render(request, "map_baidu.html", locals())